# ngme2 0.6.0
* First version of the package

# version 0.2.0
* Finish main functions

# version 0.3.0
* Add replicate feature
* Add OU process
* Add tensor-product model
