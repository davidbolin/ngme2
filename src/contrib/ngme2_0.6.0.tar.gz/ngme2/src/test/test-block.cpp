// simple test for block

#include <testthat.h>
#include <iostream>
#include "../block.h"
#include "optimizer.h"


context("tests for BlockModel") {

    BlockModel test_block; 
    

    
    test_that("test for sampleW function") {
        // Need V, K , A, Mu, Y
        expect_true(1 < 2);
    }

}
