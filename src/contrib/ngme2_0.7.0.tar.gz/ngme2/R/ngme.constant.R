#' Show ngme noise types
#'
#' @return available types for noise
#' @export
ngme_noise_types <- function() {
    c("normal", "nig", "gal", "normal_nig")
}

#' Show ngme model types
#'
#' @return available types for models
#' @export
ngme_model_types <- function() {
    c("ar1", "matern", "rw", "ou", "tp", "iid", "re", 
        "bv", "bv_matern_normal", "bv_normal", "spacetime")
}

#' Show ngme priors
#'
#' @return available types of priors
#' @export
ngme_prior_types <- function() {
    c("none", "normal", "pc.sd", "half.cauchy", "jeffery")
}

